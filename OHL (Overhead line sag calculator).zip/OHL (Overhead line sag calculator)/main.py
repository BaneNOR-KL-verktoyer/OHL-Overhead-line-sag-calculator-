import copy
import Defn
import Default
from math import sqrt, sinh, cosh, tanh, asinh, acosh, atanh, e
import Gui
from tkinter import *
g = 9.81      # Gravitational acceleration

# ... Results object...

def Beregn():
    Defn.cat_T0.info.banestrekning = Gui.var_strekning.get()
    Defn.cat_T0.info.km = Gui.var_km.get()
    Defn.cat_T0.info.nedheng_nr = Gui.var_nedheng_nr.get()
    Defn.cat_T0.info.projnr = Gui.var_prj_nr.get()
    Defn.cat_T0.info.sign = Gui.var_sign.get()
    Defn.cat_T0.info.dato = Gui.var_dato.get()
    Defn.cat_T0.geometry.L = Gui.var_L.get()
    Defn.cat_T0.geometry.dh = Gui.var_dh.get()

    Defn.Temp_list.max = Gui.var_max_temp.get()
    Defn.Temp_list.min = Gui.var_min_temp.get()
    Defn.Temp_list.ks = Defn.temp_sc(Defn.cat_T1, Gui.var_max_temp.get())
    Defn.Temp_list.montering = Gui.var_mont_temp.get()
    Defn.Temp_list.sample1 = Gui.var_temp1.get()
    Defn.Temp_list.sample2 = Gui.var_temp2.get()

    Defn.cat_T0.ledning.navn = Gui.var_ledningstype.get()

    for x in Defn.Alle_ledning_typer:
        if x.navn == Defn.cat_T0.ledning.navn:
            Defn.cat_T0.ledning = copy.deepcopy(x)

    Defn.cat_T0.ledning.nyttelast_faktor = Gui.var_nyttelastfaktor.get()
    Defn.cat_T0.krefter.T_tillat = int(Defn.cat_T0.ledning.brudlast * Defn.cat_T0.ledning.nyttelast_faktor)
    Gui.betingelser_label_0b = Label(Gui.betingelser_frame, text=(Defn.cat_T0.krefter.T_tillat/1000), bg="white").grid(row=2, column=1)

    if (Gui.betingelse.get() == 1):
        Defn.cat_T0.krefter.T_tillat = Gui.maks_strekk.get()*1000

    Defn.cat_T0.current.Isc = Gui.var_ks_i.get()
    Defn.cat_T0.current.dt_sc = Gui.var_ks_tid.get()

    Gui.label_ks_temptall = Label(Gui.korts_frame, text=str(round(Defn.temp_sc(Defn.cat_T1, Gui.var_max_temp.get()))),
                                  width=0, font=("bold", 10))
    Gui.label_ks_temptall.grid(row=2, column=1)

    Defn.cat_T0.temp = Gui.var_min_temp.get()
    Defn.iteration_1(Defn.cat_T0)

    Defn.cat_T1 = copy.deepcopy(Defn.cat_T0)
    Defn.cat_T1.temp = Gui.var_mont_temp.get()
    Defn.iteration_2(Defn.cat_T0, Defn.cat_T1)

    Defn.cat_T2 = copy.deepcopy(Defn.cat_T0)
    Defn.cat_T2.temp = Gui.var_temp1.get()
    Defn.iteration_2(Defn.cat_T0, Defn.cat_T2)

    Defn.cat_T3 = copy.deepcopy(Defn.cat_T0)
    Defn.cat_T3.temp = Gui.var_temp2.get()
    Defn.iteration_2(Defn.cat_T0, Defn.cat_T3)

    Defn.cat_T4 = copy.deepcopy(Defn.cat_T0)
    Defn.cat_T4.temp = Gui.var_max_temp.get()
    Defn.iteration_2(Defn.cat_T0, Defn.cat_T4)

    Defn.cat_T5 = copy.deepcopy(Defn.cat_T0)
    Defn.cat_T5.temp = Defn.Temp_list.ks
    Defn.iteration_2(Defn.cat_T0, Defn.cat_T5)

    Gui.destroy_all()
    window = Gui.Result_window(Gui.root)
    window.display(Defn.cat_T0, 1)
    window.display(Defn.cat_T1, 2)
    window.display(Defn.cat_T2, 3)
    window.display(Defn.cat_T3, 4)
    window.display(Defn.cat_T4, 5)
    window.display(Defn.cat_T5, 6)


button = Button(Gui.root, text="Beregn",  width=0, font =("bold", 15), command=Beregn)
button.place(x=580, y=420)
Gui.root.mainloop()