#Default verdier: nominelle strøm, kortslutning strøm og kortslutningsvarighet
current= [1200, 20000, 0.1] # Nominal current, short circuit current, short circuit duration
Temp_data = [80, -40, 10, 100, 0, 30] # Temp_max, Temp_min, Temp_montasje, Temp_kortslutning,...
                                          # Temp_1, Temp_2
info = ["0010 Oslo S", 0.1, 1, "#BNR001", "ANONYM", "01.01.2020"] #