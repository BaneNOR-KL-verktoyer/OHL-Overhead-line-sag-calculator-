# Definisjoner av klasser og funksjoner

# Constants
import Lister
import Default
import math
sqrt = math.sqrt; sinh = math.sinh; cosh = math.cosh; tanh = math.tanh
asinh = math.asinh; acosh = math.acosh; atanh = math.atanh; e = math.e
g = 9.81            # Gravitational acceleration

ledningstype = ['AAC_239_AL1', 'AAC_294_AL1', 'AAC_381_AL1', 'AAAC_299_AL3', 'AAAC_280_AL6', 'ACSR_300_GOAT',
                 'ACCR_573_T16', 'ACPR_288_38', 'ACCC_285', 'AC_100_CuAg0_1']
ledningstype.sort()
# ***********************


class Info:         # Hjelpe informasjon
    def __init__(self, data):
        self.banestrekning = data[0]
        self.km = data[1]
        self.nedheng_nr = data[2]
        self.projnr = data[3]
        self.sign = data[4]
        self.dato = data[5]


class Current:      # Nominal current, short-circuit current and duration of short-circuit current
    def __init__(self, data):
        self.nominal = data[0]
        self.Isc = data[1]
        self.dt_sc = data[2]


class Temperature:  # Temperature points for calculating the cable suspension
    def __init__(self, data):
        self.max = data[0]
        self.min = data[1]
        self.montering = data[2]
        self.ks = data[3]
        self.sample1 = data[4]
        self.sample2 = data[5]


Temp_list = Temperature(Default.Temp_data)


class Geometry:     # Geometry of the catenary (distance between masts and height difference between the two ends)
    def __init__(self):
        self.L = 75
        self.dh = 4
        self.l_med_stk= 70
        self.dl_dH = 0
        self.El_stk= 0
        self.dEl_stk = 0
        self.l_uten_stk = 70
        self.pil_h = 0.1
        self.pil_h_tillat = 0.8


class luftledning:
    def __init__(self, data):
        self.navn = data[0]
        self.max_op_temp = data[1]
        self.c_spec = data[2]
        self.alfa_T = data[3]
        self.ro = data[4]
        self.To = 20
        self.alfa_r = data[5]
        self.m_per_lengde = data[6]
        self.Youngs_mod = data[7]
        self.X_areal = data[8]
        self.brudlast = data[9]
        self.nyttelast_faktor = 0.4

AAAC_280_AL6 = luftledning(Lister.AAAC_280_AL6[0:10])
AAAC_299_AL3 = luftledning(Lister.AAAC_299_AL3[0:10])
AAC_239_AL1 = luftledning(Lister.AAC_239_AL1[0:10])
AAC_294_AL1 = luftledning(Lister.AAC_294_AL1[0:10])
AAC_381_AL1 = luftledning(Lister.AAC_381_AL1[0:10])
ACCC_285 = luftledning(Lister.ACCC_285[0:10])
ACCR_573_T16 = luftledning(Lister.ACCR_573_T16[0:10])
ACPR_288_38 = luftledning(Lister.ACPR_288_38[0:10])
ACSR_300_GOAT = luftledning(Lister.ACSR_300_GOAT[0:10])
AC_100_CuAg0_1 = luftledning(Lister.AC_100_CuAg0_1[0:10])
Alle_ledning_typer = {AAAC_280_AL6, AAAC_299_AL3, AAC_239_AL1, AAC_294_AL1, AAC_381_AL1, ACCC_285, ACCR_573_T16, ACPR_288_38, ACSR_300_GOAT, AC_100_CuAg0_1}

class krefter:
    def __init__(self):
        self.last_faktor = 0.4
        self.H = 3000
        self.Tmax = 3200
        self.dTmax_dH = 0
        self.T_tillat = 2*self.H

class catenary:
    def __init__(self, Temp):
        self.info = Info(Default.info)
        self.ledning = AAAC_280_AL6
        self.krefter = krefter()
        self.krefter.T_tillat = self.ledning.Youngs_mod * self.ledning.X_areal * self.krefter.last_faktor
        self.geometry = Geometry()
        self.current = Current(Default.current)
        self.temp = Temp
        self.krefter.T_tillat = self.krefter.last_faktor*self.ledning.brudlast


def len_med_stk(H, w, L, dh):
    return sqrt(2*(H/w)**2*(cosh(w*L/H)-1)+dh**2)


def El_stk(H, w, L, dh, e_young, area):
    return (H*L+(H**2/w)*sinh(w*L/H)+w*dh**2/tanh(w*L/(2*H)))/(2*e_young*area)


def pil_h(H, w, L, dh):
    x = (w*L)/(2*H)
    p = sqrt((2*H*sinh(x))**2+(w*dh)**2)/(2*w*tanh(x))
    q = (asinh(dh/L)-asinh(w*dh/(2*H*sinh(x))))/(2*x)
    r = -sqrt(L**2+dh**2)/(2*x)
    return p+q+r


def T_max(H, w, L, dh):
    x = (w*L)/(2*H)
    return sqrt((2*H*sinh(x))**2+(w*dh)**2)/(2*tanh(x))+w*dh/2


def dl_dH(H, w, L, dh):
    x = w*L/H
    p = 2*H*(cosh(x)-1)-(w*L/2)*sinh(x)
    q = w**2*sqrt(2*(H/w)**2*(cosh(w*L/H)-1)+dh**2)
    return p / q


def dTmax_dH(H, w, L, dh):
    x = (w*L)/(2*H)
    p = H*sinh(2*x)-w*L*(cosh(2*x)-1)+w*L*(w*dh/(H*sinh(x)))**2
    q = sqrt((2*H*sinh(x))**2+(w*dh)**2)
    return p / q -w*dh/(2*H**2)


def dEl_stk_dH(H, w, L, dh, e_young, area):
    x = w*L/H
    return (1/2+sinh(x)/x -cosh(x)/2 + (w*dh/(2*H*sinh(x)))**2)/(e_young*area)


def temp_sc(cat, T_start):
    Isc = cat.current.Isc
    ro = cat.ledning.ro
    alfa_r = cat.ledning.alfa_r
    To = cat.ledning.To
    c_spec = cat.ledning.c_spec
    dt_sc = cat.current.dt_sc
    m_per_lengde = cat.ledning.m_per_lengde
    v = alfa_r*Isc**2*ro*dt_sc/(c_spec*m_per_lengde)
    if (T_start == To):
        return T_start
    else:
        return To + e**v*(1+(T_start-To)*alfa_r-1)/alfa_r+To


def iteration_1(cat0):  # Funksjonen beregner strekk og pilhøyde fra tillatstrekk ved minste temperature
    delta_Tmax = cat0.krefter.Tmax-cat0.krefter.T_tillat
    L = cat0.geometry.L
    dh = cat0.geometry.dh
    w = cat0.ledning.m_per_lengde * 9.81
    while abs(delta_Tmax)>0.001:
        cat0.krefter.Tmax = T_max(cat0.krefter.H,w,L,dh)
        delta_Tmax = cat0.krefter.Tmax-cat0.krefter.T_tillat
        cat0.krefter.dTmax_dH = dTmax_dH(cat0.krefter.H, w, L, dh)
        delta_H = delta_Tmax/cat0.krefter.dTmax_dH
        cat0.krefter.H = cat0.krefter.H -(cat0.krefter.Tmax-cat0.krefter.T_tillat)/cat0.krefter.dTmax_dH
    # Final results
    cat0.geometry.l_med_stk = len_med_stk(cat0.krefter.H, w, L, dh)
    cat0.geometry.El_stk = El_stk(cat0.krefter.H, w, L, dh, cat0.ledning.Youngs_mod, cat0.ledning.X_areal)
    cat0.geometry.l_uten_stk = cat0.geometry.l_med_stk-cat0.geometry.El_stk
    cat0.geometry.pil_h = pil_h(cat0.krefter.H, w, L, dh)


def iteration_2(cat0, cat1):    # Funksjonen beregner strekk og pilhøyde ved ny temperatur punkt fra \
    # startpunktet (iterasjon_1) ved minste temperature
    L = cat1.geometry.L
    dh = cat1.geometry.dh
    w = cat1.ledning.m_per_lengde * 9.81
    delta_Temp = cat1.temp - cat0.temp
    if abs(delta_Temp) > 0.9:
        cat1.geometry.l_uten_stk = cat0.geometry.l_uten_stk * (1 + cat0.ledning.alfa_T * delta_Temp)
        cat1.geometry.l_med_stk = len_med_stk(cat1.krefter.H, w, L, dh)#cat1.geometry.l_uten_stk + cat0.geometry.dEl_stk
        fn_H = cat1.geometry.l_med_stk - cat1.geometry.El_stk - cat1.geometry.l_uten_stk
        while (abs(fn_H) > 0.00001 ):
            cat1.geometry.l_med_stk = len_med_stk(cat1.krefter.H, w, L, dh)
            cat1.geometry.El_stk = El_stk(cat1.krefter.H, w, L, dh, cat1.ledning.Youngs_mod, cat1.ledning.X_areal)
            print(cat1.geometry.El_stk)
            fn_H = cat1.geometry.l_uten_stk + cat1.geometry.El_stk - cat1.geometry.l_med_stk
            cat1.geometry.dl = dl_dH(cat1.krefter.H, w, L, dh)
            cat1.geometry.dEl_stk = dEl_stk_dH(cat1.krefter.H, w, L, dh, cat1.ledning.Youngs_mod, cat1.ledning.X_areal)
            dfn_H = (cat1.geometry.dl - cat1.geometry.dEl_stk)
            cat1.krefter.H = cat1.krefter.H - (fn_H/dfn_H)
        cat1.geometry.l_med_stk = len_med_stk(cat1.krefter.H, w, L, dh)
        cat1.geometry.El_stk = El_stk(cat1.krefter.H, w, L, dh, cat1.ledning.Youngs_mod, cat1.ledning.X_areal)
        cat1.geometry.pil_h = pil_h(cat1.krefter.H, w, L, dh)
        cat1.krefter.Tmax = T_max(cat1.krefter.H, w, L, dh)
    else:
        cat1.geometry = cat0.geometry
        cat1.krefter = cat0.krefter


cat_T0 = catenary(-20); cat_T1 = catenary(15);  cat_T2 = catenary(15);  cat_T3 = catenary(15);  cat_T4 = catenary(15);
Temp_list.sc = temp_sc(cat_T1, Default.Temp_data[0])