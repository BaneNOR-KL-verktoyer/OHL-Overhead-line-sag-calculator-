
def _hent_tall(str):
    """Henter ut tallverdi fra string for sortering."""
    tall = [int(s) for s in str.split() if s.isdigit()]
    return tall


# Kilometrering på dictionary-format, hentet fra gamle KL_fund
kilometer = {
    "0010 Oslo S": [0.0, 0.95],
    "0011 Oslo S fra spor 17 mot Gjøvikbanen": [0.0, 0.95],
    "0012 Gjøvikbanen inn i spor 16 Oslo S": [0.15, 0.95],
    "0013 Oslo S fra spor 9 mot Hovedbanen": [0.0, 0.95],
    "0014 Hovedbanen inn i spor 7 Oslo S": [0.0, 0.95],
    "0020 Lodalen": [0.0, 0.0],
    "0022 Oslo S fra spor 9 mot Østfoldbanen": [0.394, 2.18],
    "0023 Østfoldbanen inn i spor 7 Oslo S": [0.394, 2.18],
    "0030 Alnabru": [0.0, 0.0],
    "0040 Loenga": [0.0, 0.0],
    "0210 (Oslo S) - Alnabru/Alna": [0.95, 9.041],
    "0211 Alnabru/Alna - (Oslo S)": [0.95, 9.041],
    "0220 (Alnabru/Alna) - Lillestrøm": [9.041, 22.415],
    "0221 Lillestrøm - (Alnabru/Alna)": [9.041, 22.415],
    "0230 (Lillestrøm) - Eidsvoll": [22.415, 68.904],
    "0240 (Grefsen) - (Alnabru) g.spor": [0.0, 3.18],
    "0250 (Grefsen) - (Alnabru) g.spor": [3.18, 5.19],
    "0270 Etterstad - Gardermoen(GMB)": [2.4, 52.838],
    "0271 Gardermoen - Etterstad (GMB)": [2.4, 52.838],
    "0280 (Gardermoen)-(Eidsvoll)": [52.838, 69.3],
    "0281 Venjar - (Gardermoen)": [52.838, 65.74],
    "0300 (Lillestrøm) - Kongsvinger": [20.95, 101.692],
    "0310 (Kongsvinger) - Charlottenberg": [101.692, 136.27],
    "0510 (Loenga) - (Alnabru) g.spor": [0.0, 6.3],
    "0540 (Oslo S) - Ski": [0.39, 25.585],
    "0541 Ski - (Oslo S)": [0.39, 25.585],
    "0550 (Ski) - Moss": [25.585, 61.47],
    "0551 Sandbukta- (Ski)": [25.585, 57.187],
    "0560 (Moss) - Sarpsborg": [61.47, 111.853],
    "0561 Haug - Såstad": [67.82, 73.967],
    "0570 (Sarpsborg) - Kornsjø": [111.853, 170.123],
    "0580 (Ski) - (Sarpsborg) østre linje": [0.201, 78.9282],
    "0581 Hafslundsløyfa": [78.4366, 78.826],
    "0610 (Oslo S) - Grefsen": [0.95, 7.47],
    "0611 (Grefsen) - (Oslo S)": [0.95, 6.942],
    "0620 (Grefsen) - Roa": [7.47, 58.4],
    "0630 (Roa) - Eina": [58.4, 101.585],
    "0640 (Eina) - Gjøvik": [101.585, 124.3],
    "0670 (Roa) - Hønefoss": [57.74, 90.6],
    "0700 (Eidsvoll) - Hamar": [68.904, 127.21],
    "0710 (Hamar) - Lillehammer": [127.21, 185.174],
    "0720 (Lillehammer) - Vinstra": [185.174, 267.21],
    "0721 (Vinstra) - Dombås": [267.21, 343.596],
    "1100 (Dombås) - Hjerkinn": [343.596, 382.33],
    "1110 (Hjerkinn) - Oppdal": [382.33, 430.2],
    "1111 (Oppdal) - Støren": [430.2, 502.19],
    "1120 (Støren) - Trondheim": [502.19, 552.85],
    "1121 Trondheim": [0.0, 1.51],
    "1140 Marienborg": [548.5, 549.7],
    "1400 (Oslo S) - Lysaker": [0.0, 7.827],
    "1401 Lysaker - (Oslo S)": [0.0, 7.827],
    "1410 (Lysaker) - Asker": [7.827, 24.881],
    "1411 Asker - (Lysaker)": [7.827, 24.881],
    "1420 (Asker) - Drammen": [24.881, 53.88],
    "1421 Drammen - (Asker)": [24.881, 54.07],
    "1450 Fillipstad - (Skøyen)": [0.0, 3.0],
    "1460 (Asker) - Spikkestad": [24.03, 39.03],
    "1510 (Drammen) - Eidanger": [54.07, 192.603],
    "1511 (Larvik) - (Drammen)": [54.07, 159.173],
    "1550 (Skoppum) - Horten": [99.54, 106.51],
    "1600 (Drammen) - Hokksund": [53.88, 71.38],
    "1610 (Hokksund) - Hønefoss": [70.22, 125.3],
    "1650 (Hokksund) - Kongsberg": [71.38, 99.98],
    "1660 (Kongsberg) - Nordagutu": [99.98, 146.52],
    "1680 (Hønefoss) - Nesbyen": [90.6, 186.059],
    "1800 (Hjuksebø) - Tinnoset": [136.24, 175.3],
    "1820 (Nordagutu) - Skien": [145.95, 180.836],
    "1830 (Skien) - (Eidanger)": [180.836, 193.39],
    "2000 (Nordagutu) - Nelaug": [146.52, 282.0],
    "2120 (Nelaug) - Kristiansand": [282.0, 365.95],
    "2130 (Kristiansand) - Egersund": [365.95, 526.581],
    "2160 (Nelaug) - Arendal": [281.41, 317.64],
    "2220 (Egersund) - Stavanger": [526.581, 598.77],
    "2301 (Nesbyen) - Ål": [186.059, 228.811],
    "2310 (Ål) - (Haugastøl)": [228.811, 274.875],
    "2311 Haugastøl - Myrdal": [274.875, 336.7],
    "2312 (Myrdal) - Reimegrend": [336.7, 363.542],
    "2313 (Myrdal) - Flåm": [335.8, 356.0],
    "2320 (Reimegrend) - Voss": [363.542, 386.153],
    "2330 (Voss) - Dale": [386.153, 425.866],
    "2331 (Voss) - Palmafoss": [385.32, 389.4],
    "2340 (Dale) - Bergen": [425.866, 471.25],
    "2341 Minde - (Bergen)": [487.9, 491.3],
    "2400 Narvik havn - Vassijaure": [0.0, 42.99]}
# Kilometrering på listeformat
km_list = []
for k in kilometer:
    km_list.append(k)
km_list.sort(key=_hent_tall)

g = 9.81      #Gravitational acceleration
#Typeledning for jernbane luftlinje/luftledning
linetypeattributes = ["Navn",   "Tmp_maks", "c_spec","alfa_T","r_spec",    "alfa_r", "m_per_l", "E", "X-Areal", "brudd_last"]
AAC_239_AL1    = ["AAC_239_AL1",   80,   9.1e2,   2.3e-5,  1.204e-4,   0.00403,    0.6562, 1e11,  200e-6,   3.82e4]
AAC_294_AL1    = ["AAC_294_AL1",   80,   9.1e2,   2.3e-5,  0.981e-4,   0.00403,    0.8104, 1e11,  200e-6,   4.849e4]
AAC_381_AL1    = ["AAC_381_AL1",   80,   9.1e2,   2.3e-5,  0.757e-4,   0.00403,    1.0502, 1e11,  200e-6,   6.093e4]
AAAC_299_AL3   = ["AAAC_299_AL3",  80,   9.1e2,   2.3e-5,  1.112e-4,   0.00403,    0.8275, 1e11,  200e-6,   8.833e4]
AAAC_280_AL6   = ["AAAC_280_AL6",  80,   9.1e2,   2.3e-5,  1.127e-4,   0.00403,    0.7681, 1e11,  200e-6,   8.508e4]
ACSR_300_GOAT  = ["ACSR_300_GOAT", 80,   7.0e2,   1.8e-5,  0.891e-4,   0.00403,    1.4900, 1e11,  200e-6,   13.5e4]
ACCR_573_T16   = ["ACCR_573_T16",  80,   7.67e2,  1.67e-5, 1.161e-4,   0.00403,    0.8034, 1e11,  200e-6,   10.7754e4]
ACPR_288_38    = ["ACPR_288_38",   80,   9.1e2,   6e-6,    0.985e-4,   0.00403,    0.9010, 1e11,  200e-6,   9.5e4]
ACCC_285       = ["ACCC_285",      80,   9.1e2,   6e-6,    1.053e-4,   0.00403,    0.7470, 1e11,  200e-6,   10.135e4]
AC_100_CuAg0_1 = ["AC_100_CuAg0_1",100,  3.85e2,  1.7e-5,  1.83e-4,    0.0038,     0.8620, 1e11,  200e-6,   3.64e4]


